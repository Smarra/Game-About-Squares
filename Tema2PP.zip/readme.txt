Rulare tester din terminalul sistemului de operare:

    > stack runhaskell GASTest

Rularea unui test individual, din ghci, după încărcarea fișierului GASTest.hs:

    > runTestPP <numeTest>

Exemplu:

    > runTestPP testShowLevels
